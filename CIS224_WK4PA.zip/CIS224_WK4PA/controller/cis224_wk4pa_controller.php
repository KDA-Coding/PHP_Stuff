<?php 

    require_once('../model/cis224_wk4pa_db.php');

    function get_products()
    {
        $product_rows = get_all_products();
        $products = array();

        if($product_rows)
        {
            $index = 0;
            //if query was successfull, fill the users array
            while($row = mysqli_fetch_array($product_rows)) {
                $products[$index]["ProductNo"] = $row["ProductNo"];

                $products[$index]["Name"] = $row["Name"];
                $products[$index]["Type"] = $row["Type"];
                $index++;

            }
        }
        return $products;
    }

    /*function get_user_name($product_no) {
        
        $product = get_user($product_no);

        if($product && $product->num_rows===1)
        {
            $product_info = mysqli_fetch_assoc($product);
            return $product_info["FirstName"] . " " . $product_info["LastName"];
        }
        else {
            return "No such user or multiple users found.";
        }
    }*/

?>